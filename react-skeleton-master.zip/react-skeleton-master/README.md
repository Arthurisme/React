React skeleton by using node, babel, babelity , browserify, watchify.
